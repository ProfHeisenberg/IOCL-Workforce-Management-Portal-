// // // const express = require("express");
// // // const mongoose = require("mongoose");
// // // const bodyParser = require("body-parser");
// // // const path = require("path");
// // // const Admin = require("./models/Admin");

// // // const app = express();
// // // app.use(bodyParser.urlencoded({ extended: true }));
// // // app.use(express.static("public"));

// // // mongoose.connect("mongodb://localhost:27017/iocl_admin", {
// // //     useNewUrlParser: true,
// // //     useUnifiedTopology: true
// // // });

// // // // Serve login page
// // // app.get("/", (req, res) => {
// // //     res.sendFile(path.join(__dirname, "public", "login.html"));
// // // });

// // // // Login route
// // // app.post("/login", async (req, res) => {
// // //     const { email, password } = req.body;
// // //     const admin = await Admin.findOne({ email });

// // //     if (!admin) {
// // //         return res.send("Admin not found.");
// // //     }

// // //     if (admin.password === password) {
// // //         return res.send("Login successful!");
// // //     } else {
// // //         return res.send("Incorrect password.");
// // //     }
// // // });

// // // app.listen(3000, () => {
// // //     console.log("Server running on http://localhost:3000");
// // // });
// // // server.js

const express = require("express");
const mongoose = require("mongoose");
// const bodyParser = require("body-parser");
const path = require("path");
const Admin = require("./models/Admin"); // Don't include .js, Node auto-detects it
const Employee = require("./models/Employee");

// const Employee = require("./models/Employee");


const app = express(); //  Make sure this line exists and comes BEFORE any app.get/app.post calls

// Middleware
// app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded({ extended: true })); //  Correct way

app.use(express.json()); //  important for parsing JSON body
app.use(express.static("public")); //  for static files

// Connect to MongoDB
mongoose.connect("mongodb://localhost:27017/iocl_admin", {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

/////
app.use((req, res, next) => {
  console.log(`[${req.method}] ${req.url}`);
  next();
});

// Serve login page
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "login.html"));
});

// Login route
app.post("/login", async (req, res) => {
    const { email, password } = req.body;
     console.log("Received:", email, password);
    const admin = await Admin.findOne({ email });
    console.log("Found in DB:", admin);

    if (!admin) {
        return res.send("Admin not found.");
    }
if (admin.password === password) {
    return res.redirect("/dashboard.html"); // server redirects
}



 else {
        return res.send("Incorrect password.");
    }
});


//////////////////////////////////////////
const Attendance = require("./models/Attendance");

// API route to get department-wise present counts
app.get("/dashboard-data", async (req, res) => {
  try {
    const data = await Attendance.aggregate([
      {
        $match: { present: true }
      },
      {
        $group: {
          _id: "$department",
          presentCount: { $sum: 1 }
        }
      }
    ]);
     console.log("Fetched Data from MongoDB:", data); //  Debug
    res.json(data);
  } catch (err) {
    console.error("Error in /dashboard-data:", err);
    res.status(500).send("Error fetching dashboard data");
  }
});
/////////////////////////////////////////////
app.get("/test", (req, res) => {
  res.send("Test route working");
});
/////////////////////

//  Make sure this route exists


// const Employee = require("./models/Employee");

app.post("/register-employee", async (req, res) => {
  console.log("✅ POST /register-employee hit");
  const { name, email, department } = req.body;

  if (!name || !email || !department) {
    return res.status(400).send("Missing required fields");
  }

  try {
    const existingEmployee = await Employee.findOne({ email });
    if (existingEmployee) {
      return res.status(409).send("Employee with this email already exists.");
    }

    const newEmp = new Employee({ name, email, department });
    await newEmp.save();
    res.send("✅ Employee registered successfully.");
  } catch (err) {
    console.error(" Error registering employee:", err);
    res.status(500).send(" Failed to register employee.");
  }
});


////////////
// app.get("/register", (req, res) => {
//   res.sendFile(path.join(__dirname, "public", "register.html"));
// });







// Update employee
app.put("/employee/:id", async (req, res) => {
  const { id } = req.params;
  const { name, email, department } = req.body;
  try {
    const updated = await Employee.findByIdAndUpdate(id, { name, email, department }, { new: true });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: "Update failed" });
  }
});

// Delete employee
app.delete("/employee/:id", async (req, res) => {
  const { id } = req.params;
  try {
    await Employee.findByIdAndDelete(id);
    res.json({ message: "Deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: "Delete failed" });
  }
});



// //fetching employee
app.get("/employees", async (req, res) => {
  try {
    const employees = await Employee.find({});
    res.json(employees);
  } catch (error) {
    res.status(500).send("Error fetching employees");
  }
});
//////
app.use((req, res) => {
  res.status(404).send("Page not found");
});

// Start server
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});


