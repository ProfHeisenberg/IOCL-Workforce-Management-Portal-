// const mongoose = require("mongoose");

// const AdminSchema = new mongoose.Schema({
//     email: String,
//     password: String
// },{ collection: 'adminz' }); // 👈 Force it to use the 'admin' collection

// module.exports = mongoose.model("Adminz", AdminSchema);
const mongoose = require("mongoose");

const adminSchema = new mongoose.Schema({
  email: String,
  password: String
});

module.exports = mongoose.model("Admin", adminSchema);
