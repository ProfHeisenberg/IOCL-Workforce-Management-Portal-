// models/Attendance.js
// const mongoose = require("mongoose");

// const AttendanceSchema = new mongoose.Schema({
//   name: String,
//   department: String,
//   date: Date,
//   present: Boolean
// }, { collection: 'Attendances' }); // 👈 Force it to match your actual collection name

// module.exports = mongoose.model("Attendance", AttendanceSchema);

const mongoose = require("mongoose");

const attendanceSchema = new mongoose.Schema({
  name: String,
  department: String,
  //date: Date,
  present: Boolean // 👈 this is what your dashboard expects
});

module.exports = mongoose.model("Attendance", attendanceSchema,'Attendances');

