// import React from "react";

// function Login(){
//     return(
//         <div>
//             Login
//         </div>
//     )
// }
// export default Login;


import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';

import axios from 'axios'

function Login() {
    const [email,setEmail] = useState()
    const [password,setPassword] = useState()
    const navigate = useNavigate()

    const handleSubmit=(e)=>{
        e.preventDefault()
       axios.post("http://localhost:3001/login", {
  email: email,
  password: password
})

  .then(result => {
    console.log(result.data)
    if (result.data === "success")
      navigate('/home')
    else
      alert(result.data)
  })
  .catch(err => console.log(err))

    }
  return (
    <>
      <style>{`
        html, body, #root {
          height: 100%;
          margin: 0;
          padding: 0;
        }

        .outer {
          height: 100vh;
          width: 100vw;
          display: flex;
          justify-content: center;
          align-items: center;
          background: linear-gradient(to right, #fbe6e3, #f7f1ec);
          font-family: 'Segoe UI', sans-serif;
          padding: 20px;
          box-sizing: border-box;
        }

        .form-box {
          background-color: #ffffff;
          padding: 30px;
          border-radius: 12px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
          width: 100%;
          max-width: 450px;
          box-sizing: border-box;
          border-top: 8px solid #a72029;
        }

        .form-box h1 {
          text-align: center;
          margin-bottom: 10px;
          font-size: 28px;
          color: #a72029; /* IOCL deep red */
        }

        .form-box h2 {
          text-align: center;
          margin-bottom: 25px;
          font-size: 20px;
          color: #444;
        }

        .form-box input {
          width: 100%;
          padding: 12px;
          margin-bottom: 15px;
          border: 1px solid #ccc;
          border-radius: 6px;
          font-size: 16px;
        }

        .form-box button {
          width: 100%;
          padding: 12px;
          background-color: #a72029;
          color: white;
          border: none;
          border-radius: 6px;
          font-size: 16px;
          cursor: pointer;
        }

        .form-box button:hover {
          background-color:rgb(0, 0, 0);
        }

        .form-box p {
          text-align: center;
          margin-top: 15px;
          font-size: 14px;
          color: #555;
        }

        .form-box a {
          color: #a72029;
          text-decoration: none;
        }

        .form-box a:hover {
          text-decoration: underline;
        }

        @media (max-width: 768px) {
          .form-box {
            padding: 20px;
          }
        }

        @media (max-width: 480px) {
          .form-box h1 {
            font-size: 22px;
          }

          .form-box h2 {
            font-size: 16px;
          }

          .form-box input,
          .form-box button {
            font-size: 14px;
            padding: 10px;
          }
        }
      `}</style>

   

      <div className="outer">
        <div className="form-box">
          <h1>Admin Login</h1>
          <h2>IOCL Workforce Management Portal</h2>
          <form onSubmit={handleSubmit}>
            <input type="email" placeholder="Enter Email" required 
            onChange={(e)=>setEmail(e.target.value)}/>
            <input type="password" placeholder="Enter Password" required
            onChange={(e)=>setPassword(e.target.value)} />
            <button type="submit">Login</button>
          </form>
          <p>
            Don't have an account?{' '}
            <a href="/register">Register</a>
          </p>
        </div>
      </div>
    </>
  );
}

export default Login;




