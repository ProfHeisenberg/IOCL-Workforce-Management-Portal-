import React from 'react';

function Home() {
  return (
    <div style={styles.container}>
      <div style={styles.box}>
        <h1 style={styles.heading}>Welcome, Admin!</h1>
        <p style={styles.text}>You have successfully logged into the IOCL Workforce Management Portal.</p>
      </div>
    </div>
  );
}

const styles = {
  container: {
    height: '100vh',
    width: '100vw',
    background: 'linear-gradient(to right, #fff2e6, #ffd9cc)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    fontFamily: 'Segoe UI, sans-serif'
  },
  box: {
    backgroundColor: '#fff',
    padding: '40px',
    borderRadius: '12px',
    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
    textAlign: 'center',
    maxWidth: '500px',
    width: '90%'
  },
  heading: {
    fontSize: '28px',
    color: '#a72029',
    marginBottom: '15px'
  },
  text: {
    fontSize: '18px',
    color: '#555'
  }
};

export default Home;
