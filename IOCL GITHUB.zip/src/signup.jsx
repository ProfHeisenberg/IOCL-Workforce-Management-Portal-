import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';

function Signup() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:3001/register',axios.post("/register", {
  email,
  password
})/*{ email, password }*/)
      .then(result => {
        console.log(result.data);
        if (result.data === "registered") {
          navigate('/login');
        } else {
          alert("Registration failed");
        }
      })
      .catch(err => {
        console.log(err);
        alert("Something went wrong");
      });
  };

  return (
    <>
      <style>{`
        .outer {
          height: 100vh;
          width: 100vw;
          display: flex;
          justify-content: center;
          align-items: center;
          background: linear-gradient(to right, #f7ecea, #fbe6e3);
          font-family: 'Segoe UI', sans-serif;
          padding: 20px;
        }

        .form-box {
          background-color: #fff;
          padding: 30px;
          border-radius: 12px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
          width: 100%;
          max-width: 450px;
          border-top: 8px solid #a72029;
        }

        .form-box h1 {
          text-align: center;
          margin-bottom: 20px;
          font-size: 26px;
          color: #a72029;
        }

        .form-box input {
          width: 100%;
          padding: 12px;
          margin-bottom: 15px;
          border: 1px solid #ccc;
          border-radius: 6px;
          font-size: 16px;
        }

        .form-box button {
          width: 100%;
          padding: 12px;
          background-color: #a72029;
          color: white;
          border: none;
          border-radius: 6px;
          font-size: 16px;
          cursor: pointer;
        }

        .form-box button:hover {
          background-color: black;
        }

        .form-box p {
          text-align: center;
          margin-top: 15px;
          font-size: 14px;
          color: #555;
        }

        .form-box a {
          color: #a72029;
          text-decoration: none;
        }

        .form-box a:hover {
          text-decoration: underline;
        }

        @media (max-width: 480px) {
          .form-box h1 {
            font-size: 22px;
          }

          .form-box input,
          .form-box button {
            font-size: 14px;
            padding: 10px;
          }
        }
      `}</style>

      <div className="outer">
        <div className="form-box">
          <h1>Admin Signup</h1>
          <form onSubmit={handleSubmit}>
            <input type="email" placeholder="Enter Email" required
              onChange={(e) => setEmail(e.target.value)} />
            <input type="password" placeholder="Enter Password" required
              onChange={(e) => setPassword(e.target.value)} />
            <button type="submit">Register</button>
          </form>
          <p>
            Already have an account? <Link to="/login">Login</Link>
          </p>
        </div>
      </div>
    </>
  );
}

export default Signup;
